<!DOCTYPE html>
<html lang='en'>
  <head>
    <meta charset='utf-8' />
    <link rel="stylesheet" href="../lib/css/style.css">
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.9/index.global.min.js'></script>
    <script>

      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
          height: 'auto',
          width: 'auto',
          initialView: 'timeGridWeek',
          expandRows: true,
          slotMinTime: '00:00',
          slotMaxTime: '24:00',
          navLinks: true,
          editable: true,
          selectable: true,
          nowIndicator: true,
          dayMaxEvents: true
        });
        calendar.render();
        
      });

    </script>
    <?php include("menu.php");?>
  </head>
  <body>

    <div id='calendar'>
      <!-- Div para exibir o calendário -->
    </div>

    <div>
      <button class="button">+</button>
    </div>
  </body>
</html>