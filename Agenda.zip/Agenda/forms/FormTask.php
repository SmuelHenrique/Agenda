<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Tarefas</h2>
  <form action="/action_page.php">
    <div class="mb-3 mt-3">
      <label for="email">Nome:</label>
      <input type="text" class="form-control" id="nome" placeholder="Enter email" name="email">
    </div>
    <div class="mb-3">
      <label for="pwd">Data:</label>
      <input type="date" class="form-control" id="data" placeholder="Enter password" name="pswd">
    </div>
    <div class="mb-3">
      <label for="pwd">Horário:</label>
      <input type="time" class="form-control" id="data" placeholder="Enter password" name="pswd">
    </div>
    <div class="mb-3">
      <label for="pwd">Prioridade:</label>
      <input type="time" class="form-control" id="data" placeholder="Enter password" name="pswd">
    </div>
    <div class="container mt-3">
        <h2>Descrição</h2>
        
            <div class="mb-3 mt-3">
            <label for="comment">Comments:</label>
            <textarea class="form-control" rows="5" id="comment" name="text"></textarea>
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>