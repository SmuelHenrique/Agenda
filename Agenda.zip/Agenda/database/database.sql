create database calendario;
use calendario;

create table usuario(
	email varchar(100) PRIMARY KEY,
    nome varchar(100) not null,
    aniversario date
);

create table compromisso(
	id int PRIMARY KEY AUTO_INCREMENT,
    proprietario varchar(100) not null,
    nome varchar(50) not null,
    data date not null,
    horario time not null,
    descricao varchar(250) not null,
    FOREIGN KEY (proprietario) REFERENCES usuario(email)
);