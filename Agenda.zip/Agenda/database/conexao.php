
<!-- Conxão do php -->
    <?php
        try {

            $host='localhost';
            $db = 'calendario';
            $username = 'root';
            $password = 'ifsp';
            $dbh = new PDO('mysql:host='.$host.';dbname='.$db.'', $username, $password);
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage();
            die();
        }
        
    ?>

<!-- Métodos pra acessar obanco -->
        <!-- Manipulação da tabela usuário -->
            <?php
                function registerUser(){
                    try {
                        $stmt = $dbh->prepare("INSERT INTO usuario() VALUES(?, ?, ?);");
                        $stmt->bindParam(1, var1);
                        $stmt->bindParam(2, var2);
                        $stmt->bindParam(3, var3);
                    } catch (\Throwable $th) {
                        //throw $th;
                    }
                }
            ?>

            <?php
                function deleteUser(){
                    try {
                        $stmt = $dbh->prepare("DELETE FROM usuario() WHERE email = ?;");
                        $stmt->bindParam(1, var1);
                    } catch (\Throwable $th) {
                        //throw $th;
                    }
                }
            ?>

        <!-- Manipulação da tabela compromisso -->
            <?php
                function registerTask(){
                    try {
                        $stmt = $dbh->prepare("INSERT INTO compromisso() VALUES(?, ?, ?, ?, ?);");
                        $stmt->bindParam(1, var1);
                        $stmt->bindParam(2, var2);
                        $stmt->bindParam(3, var3);
                        $stmt->bindParam(4, var4);
                        $stmt->bindParam(5, var5);
                    } catch (\Throwable $th) {
                        //throw $th;
                    }
                }
            ?>

            <?php
                function deleteTask(){
                    try {
                        $stmt = $dbh->prepare("DELETE FROM compromisso() WHERE proprietario = ? AND id = ?;");
                        $stmt->bindParam(1, var1);
                        $stmt->bindParam(2, var2);
                    } catch (\Throwable $th) {
                        //throw $th;
                    }
                }
            ?>

            <?php
                function updateTask(){
                    try {
                        $stmt = $dbh->prepare("UPDATE compromisso() SET nome = ?, data = ?, horario = ?, descricao = ? WHERE proprietario = ? AND id = ?;");
                        $stmt->bindParam(1, var1);
                        $stmt->bindParam(2, var2);
                        $stmt->bindParam(3, var3);
                        $stmt->bindParam(4, var4);
                        $stmt->bindParam(5, var5);
                        $stmt->bindParam(6, var6);
                    } catch (\Throwable $th) {
                        //throw $th;
                    }
                }
            ?>