<?php
    include('connectionEvent.php');

    $objEvents = new events();
    try {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $date = $_POST['date'];
        $startTime = $_POST['startTime'];
        $endTime = $_POST['endTime'];
        $color = $_POST['color'];
        $description = $_POST['description'];
        //$startTime = new \DateTime($startTimeBrute);
        //$endTime = new \DateTime($endTimeBrute);

        $objEvents->updateEvent($id, $title, $date, $startTime, $endTime, $color, $description);
        
    } catch (\PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }

?>

    <?php
    // teste para ser utilizado para verificar se os botões funcionam
        // if (isset($_POST['btnUpdate'])) {
        //     header("location: backEnd/updateEvent.php");
        // } elseif(isset($_POST['btnDelete'])){
        //     header("location: backEnd/updateEvent.php");
        // }
    ?>