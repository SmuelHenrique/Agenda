<?php
    // Dentro dessa página os dados coletados serão transformados em Json.
        // Após isso serão passados ao calendário nesse formato
    use connection;

    class events extends connection {
        // Aqui será trazidos os dados
        public function getEvents(){ // Essa função trará todos os eventos presentes no banco de dados
        // Parece que deveremos, após coletar os dados, enviá-los para uma página que conterá apenas os arquivos JSON
            try {
                $b = $this->connection()->prepare("SELECT * FROM eventsN");
                $b->execute();
                $f = $b->fetchAll(\PDO::FETCH_ASSOC);
                return json_encode($f); // Após coletarmos os dados eles são transformados em Json
                    // Isso porque o calendário registra seu eventos em JSON
                    // Dentro do tutorial ele ainda passa um echo após a passagem de JSON
                        // Muito possivelmente para ter o modelo em String
            } catch (\PDOException $e) {
                return $e -> getMessage();
            }
        }

        public function insertEvent($title, $date, $startTime, $endTime, $color, $description){
            // Função utilizada para inserir um evento no banco de dados
            try {
                $b = $this->connection()->prepare('INSERT INTO eventsN() VALUES(?, ?, ?, ?, ?, ?)');
                //$b->prepare('INSERT INTO events() VALUES(?, ?, ?, ?, ?, ?)');
                $b->bindParam(1, $title, \PDO::PARAM_STR);
                $b->bindParam(2, $date, \PDO::PARAM_STR);
                $b->bindParam(3, $startTime, \PDO::PARAM_STR);
                $b->bindParam(4, $endTime, \PDO::PARAM_STR);
                $b->bindParam(5, $color, \PDO::PARAM_STR);
                $b->bindParam(6, $description, \PDO::PARAM_STR);

                $b->execute();
            } catch (\PDOException $e) {
                return $e -> getMessage();
            }
            
        }

        public function updateEvent($id, $title, $date, $startTime, $endTime, $color, $description){
            // Função utilizada para atualizar um evento no banco de dados
            try {
                $b = $this->connection()->prepare('UPDATE eventsN 
                    SET title=?, date=?, startTime=?, endTime=?, color=?, description=? WHERE id=?');
                $b->bindParam(1, $title, \PDO::PARAM_STR);
                $b->bindParam(2, $date, \PDO::PARAM_STR);
                $b->bindParam(3, $startTime, \PDO::PARAM_STR);
                $b->bindParam(4, $endTime, \PDO::PARAM_STR);
                $b->bindParam(5, $color, \PDO::PARAM_STR);
                $b->bindParam(6, $description, \PDO::PARAM_STR);
                $b->bindParam(7, $id, \PDO::PARAM_INT);

                $b->execute();
            } catch (\PDOException $e) {
                return $e -> getMessage();
            }
            
        }

        public function deleteEvent($id){
            // Função utilizada para excluir um evento no banco de dados
            try {
                $b = $this->connection()->prepare('DELETE FROM eventsN WHERE id=?');
                $b->bindParam(1, $id, \PDO::PARAM_INT);

                $b->execute();
            } catch (\PDOException $e) {
                return $e -> getMessage();
            }
            
        }
    }
?>