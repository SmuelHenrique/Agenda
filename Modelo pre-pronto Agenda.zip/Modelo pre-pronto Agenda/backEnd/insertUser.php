<?php
    include("connection.php");
    require_once 'users.php';
    $objUser = new users();

    try {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $objUser->insertUser($name, $email, $password);
    } catch (\PDOException $e) {
        return $e->getMessage();
    }
    
?>