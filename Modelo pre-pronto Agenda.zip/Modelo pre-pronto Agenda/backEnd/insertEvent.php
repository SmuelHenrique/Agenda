<?php
    include('connectionEvent.php');

    $objEvents = new events();
    try {
        $title = $_POST['title'];
        $date = $_POST['date'];
        $startTime = $_POST['startTime'];
        $endTime = $_POST['endTime'];
        $color = $_POST['color'];
        $description = $_POST['description'];
        //$startTime = new \DateTime($startTimeBrute);
        //$endTime = new \DateTime($endTimeBrute);

        $objEvents->insertEvent($title, $date, $startTime, $endTime, $color, $description);

    } catch (\PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }
?>