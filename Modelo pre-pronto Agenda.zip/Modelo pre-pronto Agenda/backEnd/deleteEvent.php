<?php
    include('connectionEvent.php');

    $objEvents = new events();
    try {
        $id = $_POST['id'];

        $objEvents->deleteEvent($id);
        
    } catch (\PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }
    
?>