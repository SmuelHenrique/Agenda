<?php
    abstract class connectionUser{ // Aqui o professor/youtuber disse que deveria ser abstract para não ser instanciada
    // Todo esse bloco é a conexão com o banco de dados    
        public function conexaoUser(){
            try {
                $con = new \PDO("mysql:host="."HOST".";dbname="."DATABSE"."", "USER", "PASS"); // Aqui está a conexão com o banco de daos
                return $con;
                //Código da conexão que eu já devemos ter pronto em algum lugar
            } catch (\PDOException $e) {
                return $e -> getMessage();
            }
        }
    }
    // Aqui foi o fim da conexão com obanco de dados
?>