<?php
    if(isset($_POST['btnUpdate'])){
        header("location: backEnd/insertEvent.php");
    } else if(isset($_POST['btnDelete'])){
        header("location: backEnd/deleteEvent.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.9/index.global.min.js'></script>
    <script src="javaScript/scriptCalendarMonth.js" defer></script>
    <script src="javaScript/scriptModal.js" defer></script>
    <link rel="stylesheet" href="style.css">
    <title>Página de visualização Mesal</title>
  </head>
  <body>
    <div id='calendarMonth'></div>

    <button type="button" id="btn(+)" style="z-index: 2;" class="button">+</button>

    <!-- Aqui se encontra o modal -->
    <div id="modal(+)" class="modal"> 
        <!--Esse modal será exibido quando a seta for clicada, 
        ou seja, só é possível cadastrar um evento novo-->
        <form action="" method="post">
            <!-- Modal content -->
            <div class="modal-content">
                <div class="modal-header"> 
                    <span class="close" id="closeModal">&times;</span>
                    <h2>Cadastro da Tarefa</h2>
                </div>
                <div class="modal-body">
                    <h3>Título da tarefa:</h3>
                    <input required type="text" class="title" id="title" placeholder="Insira o Título" name="title"> <br>
                    <h3>Dia da tarefa:</h3>
                    <input required type="date" class="date" id="date" name="date"> <br>
                    <h3>Horário de Início da tarefa:</h3>
                    <input required type="time" class="time" id="timeModalStart" name="startTime"> <br>
                    <h3>Horário de Término da tarefa:</h3>
                    <input required type="time" class="time" id="timeModalEnd" name="endTime"> <br>
                    <h3>Cor:</h3>
                    <select name="color" id="color" class="color">
                        <option value="blue">Azul</option>
                    </select>
                    <h3>Descrição da tarefa:</h3>
                    <input required type="text" class="description" id="description" name="description"> <br>
                </div>
                <div class="modal-footer">
                    <button class="saveBtn" id="btnSave" type="submit" name="btnSave">Salvar</button>
                </div>
            </div>
      </form>
    </div>

    <div id="modalEventClick" class="modal"> 
        <!--Esse modal será exibido quando o evento for clicado-->
        <!-- Aqui será exibido todos os dados do evento -->
        <form action="" method="post">
            <!-- Aqui não tem action poque direciona para loacais diferentes com PHP -->
            <!-- Modal content -->
            <div class="modal-content">
                <div class="modal-header"> 
                    <span class="close">&times;</span>
                    <h2>Cadastro da Tarefa</h2>
                </div>
                <div class="modal-body">
                    <h3>Título da tarefa:</h3>
                    <input required type="text" class="title" id="titleModalEventClick" placeholder="Insira o Título" name="title"> <br>
                    <h3>Dia da tarefa:</h3>
                    <input required type="date" class="date" id="dateModalEventClick" name="date"> <br>
                    <h3>Horário de Início da tarefa:</h3>
                    <input required type="time" class="time" id="timeModalStartEventClick" name="startTime"> <br>
                    <h3>Horário de Término da tarefa:</h3>
                    <input required type="time" class="time" id="timeModalEndEventClick" name="endTime"> <br>
                    <h3>Cor:</h3>
                    <select name="color" id="colorModalEventClick" class="color">
                        <option value="blue">Azul</option>
                    </select>
                    <h3>Descrição da tarefa:</h3>
                    <input required type="text" class="descriptionModalEventClick" id="description" name="description"> <br>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="saveBtn" id="btnSaveEventClick" name="btnUpdate">Salvar</button>
                    <button type="submit" class="Deletebtn" id="btnDeleteEventClick" name="btnDelete">Deletar</button>
                </div>
            </div>
      </form>
    </div>

    <div id="modalDateClick" class="modal"> 
        <!--Esse modal será exibido quando a seta for clicada, 
        ou seja, só é possível cadastrar um evento novo-->
        <!-- Nesse modal será apresentado apenas o horário  -->
        <form action="backEnd/insertEvent.php" method="post">
            <!-- Modal content -->
            <div class="modal-content">
                <div class="modal-header"> 
                    <span class="close" id="closeMonthDateClick">&times;</span>
                    <h2>Cadastro da Tarefa</h2>
                </div>
                <div class="modal-body">
                    <h3>Título da tarefa:</h3>
                    <input required type="text" class="title" id="titleModalDateClick" placeholder="Insira o Título" name="title"> <br>
                    <h3>Dia da tarefa:</h3>
                    <input required type="date" class="date" id="dateModalDateClick" name="date"> <br>
                    <h3>Horário de Início da tarefa:</h3>
                    <input required type="time" class="time" id="timeModalStartDateClick" name="startTime"> <br>
                    <h3>Horário de Término da tarefa:</h3>
                    <input required type="time" class="time" id="timeModalEndDateClick" name="endTime"> <br>
                    <h3>Cor:</h3>
                    <select name="color" id="colorModalDateClick" class="color">
                        <option value="blue">Azul</option>
                    </select>
                    <h3>Descrição da tarefa:</h3>
                    <input required type="text" class="description" id="descriptionModalDateClick" name="description"> <br>
                </div>
                <div class="modal-footer">
                    <button class="saveBtn" id="btnSaveModalDateClick" type="submit" name="btnSave">Salvar</button>
                </div>
            </div>
      </form>
    </div>

  </body>
</html>
    
