      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendarWeek');
        var calendar = new FullCalendar.Calendar(calendarEl, {
          initialView: 'timeGridWeek',
          locale: 'pt-BR',
          buttonText: {
            today: 'Hoje'
          },

          dateClick: function(info) { // Aqui é quando se clica em uma data
            // calendar.changeView('timeGrid', info.dateStr);
          },

          eventClick: function(info) { // Aqui se trata de qaundo eu clico em um evento  
            alert('Event: ' + info.event.title);
            alert('Coordinates: ' + info.jsEvent.pageX + ',' + info.jsEvent.pageY);
            alert('View: ' + info.view.type);
            // change the border color just for fun  
            info.el.style.borderColor = 'red';
          },
          events: 'Aqui vai o caminho para o local onde selecionamos os dados, no caso onde estão os eventos'

        });
        calendar.render();
      });