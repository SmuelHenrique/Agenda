document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendarMonth');
  var calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    locale: 'pt-BR',
    buttonText: {
      today: 'Hoje'
    },

    dateClick: function(info) { // Aqui é quando se clica em uma data
      if (info.view.type == "dayGridMonth") {
        calendar.changeView('timeGrid', info.dateStr);
      } else if(info.view.type == "timeGrid") {

        callModalDateClick(info);
      }
    },

    eventClick: function(info) { // Aqui se trata de qaundo eu clico em um evento  
      callModalEventClick(info);
    },

    events: '/ModeloPreProntoAgenda/backEnd/displayEvents.php'

  });
  calendar.render();
});

function callModalDateClick(info){
  // O intui será chamar o modal que abre quando clicamos em uma data

  var calendario = document.getElementById("calendarMonth");
  var modal = document.getElementById("modalDateClick");
  var span = document.getElementById("closeMonthDateClick");

  // When the user clicks the button, open the modal 
  calendario.onclick = function() {
    modal.style.display = "block";
  }

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
  }

  var date = document.getElementById("dateModalDateClick");
  var time = document.getElementById("timeModalStartDateClick");

  time.value = new Intl.DateTimeFormat('pt-BR', {hour: 'numeric', minute: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date);
  date.value = new Intl.DateTimeFormat('pt-BR', {year: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date)
    + '-' + new Intl.DateTimeFormat('pt-BR', {month: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date)
    + '-' + new Intl.DateTimeFormat('pt-BR', {day: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date);
}

function callModalEventClick(info){
  // O intui será chamar o modal que abre quando clicamos em uma data

  var calendario = document.getElementById("calendarMonth");
  var modal = document.getElementById("modalEventClick");
  var span = document.getElementById("closeMonthEventClick");

  // When the user clicks the button, open the modal 
  calendario.onclick = function() {
    modal.style.display = "block";
  }

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
  }

  var title = document.getElementById("titleModalEventClick");
  var date = document.getElementById("dateModalEventClick");
  var timeStart = document.getElementById("timeModalStartEventClick");
  var timeEnd = document.getElementById("timeModalEndEventClick");
  var color = document.getElementById("colorModalEventClick");
  var description = document.getElementById("descriptionModalEventClick");

  title.value = info.event.title;
  //timeStart.value = info.event.start;
  timeEnd.value = info.event.end;
  color.value = info.event.backGroundColor;
  description.value = info.event.start; // Não se esquecer de adicionar a descrição em extendeProps na passagem dos eventos
  timeStart.value = new Intl.DateTimeFormat('pt-BR', {hour: 'numeric', minute: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.event.start);
  timeEnd.value = new Intl.DateTimeFormat('pt-BR', {hour: 'numeric', minute: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.event.end);

  date.value = new Intl.DateTimeFormat('pt-BR', {year: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date)
    + '-' + new Intl.DateTimeFormat('pt-BR', {month: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date)
    + '-' + new Intl.DateTimeFormat('pt-BR', {day: 'numeric', timeZone: 'America/Sao_paulo'}).format(info.date);
}