<?php
    include('connection.php');
    
    try {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $date = $_POST['date'];
        $startTime = $_POST['startTime'];
        $endTime = $_POST['endTime'];
        $color = $_POST['color'];
        $description = $_POST['description'];
        
        $stmt = $con->prepare("UPDATE eventsN 
        SET title=?, date=?, startTime=?, endTime=?, color=?, description=? WHERE id=?");
        $stmt->bindParam(1, $id);
        $stmt->bindParam(2, $title);
        $stmt->bindParam(3, $date);
        $stmt->bindParam(4, $startTime);
        $stmt->bindParam(5, $endTime);
        $stmt->bindParam(6, $color);
        $stmt->bindParam(7, $description);
        $stmt->execute();

        header("location: ../month.php");
    } catch (\PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }

?>