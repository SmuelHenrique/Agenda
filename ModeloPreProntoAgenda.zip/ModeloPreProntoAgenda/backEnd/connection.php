<?php

    try {
        $HOST = "localhost";
        $DATABASE = "Agenda";
        $USER = "root";
        $PASS = "ifsp";

        $con = new PDO("mysql:host=".$HOST.";dbname=".$DATABASE, $USER, $PASS);
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage();
        die();
    }
?>