<?php
    include('connection.php');

    try {
        $title = $_POST['title'];
        $date = $_POST['date'];
        $startTime = $_POST['startTime'];
        $endTime = $_POST['endTime'];
        $color = $_POST['color'];
        $description = $_POST['description'];

        $stmt = $con->prepare("INSERT INTO eventsN() VALUES(?, ?, ?, ?, ?, ?)");
        $stmt->bindParam(1, $title);
        $stmt->bindParam(2, $date);
        $stmt->bindParam(3, $startTime);
        $stmt->bindParam(4, $endTime);
        $stmt->bindParam(5, $color);
        $stmt->bindParam(6, $description);

        $stmt->execute();
        header("location: ../month.php");

    } catch (PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }
?>