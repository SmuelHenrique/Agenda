<?php
    include('connection.php');

    try {
        $title = $_POST['title'];
        $date = $_POST['date'];
        $startTime = $date . " " . $_POST['startTime'];
        $endTime = $date . " " . $_POST['endTime'];
        $color = $_POST['color'];
        $description = $_POST['description'];

        $stmt = $con->prepare("INSERT INTO eventsN(title, start, end, color) VALUES(?, ?, ?, ?)");
        $stmt->bindParam(1, $title);
        $stmt->bindParam(2, $startTime);
        $stmt->bindParam(3, $endTime);
        $stmt->bindParam(4, $color);

        $stmt->execute();
        header("location: ../month.php");

    } catch (PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }
?>