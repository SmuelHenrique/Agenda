<?php
    // Essa página coleta os dados trazidos pelo banco de dados
        // Após a coleta em formato Json ela os "exibe". Deixando no modelo pedido pelo calendário
    //require_once 'events.php';
    
    include("connection.php");
    $stmt = $con->prepare("SELECT * FROM eventsN");
    $stmt->execute();

    $json = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo(json_encode($json));
?>