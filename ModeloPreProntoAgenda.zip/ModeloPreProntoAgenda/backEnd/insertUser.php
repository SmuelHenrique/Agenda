<?php
    include("connection.php");

    try {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $stmt = $con->prepare("INSERT INTO usersN() VALUES(?, ?, ?)");
        $stmt->bindParam(1, $name);    
        $stmt->bindParam(2, $email);    
        $stmt->bindParam(3, $password);
        $stmt->execute();
        
        header("location: ../month.php");
    } catch (\PDOException $e) {
        return $e->getMessage();
    }
    
?>