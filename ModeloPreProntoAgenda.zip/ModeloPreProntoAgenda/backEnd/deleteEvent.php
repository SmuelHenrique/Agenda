<?php
    include('connection.php');

    try {
        $id = $_POST['id'];

        $stmt = $con->prepare("DELETE FROM eventsN WHERE id = ?");
        $stmt->bindParam(1, $id);
        $stmt->execute();

        header("location: ../month.php");
    } catch (PDOException $e) {
        echo ("Houve um erro no seu código: " . $e->getMessage());
    }
    
?>