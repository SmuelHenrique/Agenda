create DATABASE Agenda;
use Agenda;

create table userN(
	email VARCHAR(100) PRIMARY KEY,
    nome VARCHAR(45) not null,
    senha INTEGER not null
);

create table eventsN(
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(45) not null,
    dateN DATE 	not null,
    timeStart TIME not null,
    timeEnd TIME not null,
    color VARCHAR(10),
    decription VARCHAR(200),
    email_user VARCHAR(100),
    FOREIGN KEY(email_user) REFERENCES userN(email)
);
-- Versão 2

create DATABASE Agenda;
use Agenda;

create table userN(
	email VARCHAR(100) PRIMARY KEY,
    nome VARCHAR(45) not null,
    senha INTEGER not null
);

create table eventsN(
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(45) not null,
    start TIMESTAMP not null,
    end TIMESTAMP not null,
    color VARCHAR(10)
);